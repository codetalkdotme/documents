CREATE DATABASE flowminer DEFAULT CHARSET 'UTF8';

grant all on flowminer.* to 'flowminer'@'%' identified by 'welcomeX';

flush privileges;



