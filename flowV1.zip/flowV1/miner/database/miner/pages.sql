-- infoq
insert into site_pages values ('5a2e7e32-1b74-4e9d-96dc-ea9c9d6ea302', 'https://www.infoq.com/news/2012/12/netflix-hystrix-fault-tolerance', 2, 3, 6, 601, null, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);



-- thenewstack
insert into site_pages values ('8ca5750d-01c2-4420-a36d-62d99a2cab9d', 'https://thenewstack.io/grpc-lean-mean-communication-protocol-microservices/', 2, 3, 7, 701, null, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);

-- martinfowler
insert into site_pages values ('fcd4b335-9271-4085-bfd0-a8464debc5b9', 'https://martinfowler.com/eaaDev/EventSourcing.html', 2, 3, 9, 901, null, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);









