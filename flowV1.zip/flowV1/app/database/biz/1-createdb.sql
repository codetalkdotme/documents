CREATE DATABASE flowbiz DEFAULT CHARSET 'UTF8';

grant all on flowbiz.* to 'flowbiz'@'%' identified by 'welcome6';

flush privileges;



