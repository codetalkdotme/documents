CREATE DATABASE flowauth DEFAULT CHARSET 'UTF8';

grant all on flowauth.* to 'flowauth'@'%' identified by 'welcome5';

flush privileges;



